from flask import Flask,render_template,request

from prep import *
app=Flask(__name__)
@app.route("/")
def home():
    return render_template("index.html",predicted=0)

@app.route('/predict',methods=["GET","POST"])
def predict():
    if request.method=="POST":
        article=request.form.get("article")
        article= preprocessing(article)
        test_ = pd.DataFrame(pipeline.transform(article.text))
        test_ = test_.join(article.drop('text', axis=1))
        if model.predict(test_)[0] == 1:
            result="Fake"
        else:
            result="Real"
        return render_template("index.html",predicted=1,result=result )

app.run(debug=True)