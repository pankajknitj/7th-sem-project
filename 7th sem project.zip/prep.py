import spacy
import pandas as pd
import numpy as np
import pickle


pipeline=pickle.load(open("pipeline.pkl",'rb'))
model=pickle.load(open("model.pkl",'rb'))
nlp=spacy.load('en_core_web_sm')
stopwords=spacy.lang.en.stop_words.STOP_WORDS


def only_alpha(text):  # Keep only alphabets,keep in mind that it will keep alphabets of any country.
    doc = nlp(text)
    alpha = [w.text for w in doc if w.text.isalpha() and w not in stopwords]  # W.text to access tocken
    return ' '.join(alpha)


def count_pos_tag(text):  # Returns the count of noun,proper noun and pronouns for each news.
    doc = nlp(text)
    tags = [w.pos_ for w in doc]  # W.pos_ gives us part of speech tag for that word.
    return tags.count('NOUN'), tags.count('PROPN'), tags.count('PRON')


def count_named_entity(
        text):  # Returns the numbers of person,location,organisation,political groups ,mentioned in the news content.
    doc = nlp(text)
    entity = [w.label_ for w in doc.ents]  # W.label_ tell us entity eg. person or place or organisation
    return entity.count('PERSON'), entity.count('GPE'), entity.count('NORP'), entity.count('ORG')


def lemma(text):  # Lemmatize the word
    doc = nlp(text)
    lemma = [w.lemma_ for w in doc]  # W.lemma_ lemmatize the word.
    return " ".join(lemma)


def preprocessing(data):  # A combined function to all the text mining works.
    data = pd.DataFrame([data], columns=['text'])
    data.text = data.text.apply(only_alpha)
    data.text = data.text.str.lower()
    print('wooh, have Only alphabetic char ')
    data['noun_count'], data['pnoun_count'], data['pron_count'] = np.array(list(data.text.apply(count_pos_tag))).T
    print('Tagged pos')
    data['num_person'], data['num_places'], data['num_national_gr'], data['num_organisation'] = np.array(
        list(data.text.apply(count_named_entity))).T
    print('lemmatisation starts')
    data.text = data.text.apply(lemma)
    return data
